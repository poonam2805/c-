﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace airthmetic
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor= ConsoleColor.White;
            Console.ForegroundColor= ConsoleColor.Black;
            Console.Clear();
            Console.WriteLine("enter 1 value:");
            int a=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter 2 value:");
            int b=Convert.ToInt32(Console.ReadLine());
            int c = a + b;
            Console.WriteLine("sum is=" + c);
            c = a - b;
            Console.WriteLine("substraction :" + c);
            c = a * b;
            Console.WriteLine("multiplication:" + c);
            c = a / b;
            Console.WriteLine("divison:" + c);
            Console.ReadKey();
        }
    }
}
