﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace loops
{
    internal class Program
    {
        private static int n1;
        private static int n2;

        static void Main(string[] args)
        {
            Console.Write("enters any number:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1, k = 1, old = 0, Temp = 0, New = 0;
            n1 = 0;
            n1 = n;
            n2 = n;
            do
            {
                int j = 1;
                do
                {
                    if (k <= 3)
                    {
                        Console.Write(k);
                        New = k;
                        old = k - 1;
                    }
                    else
                    {
                        Temp = old * New;
                        if (Temp > n)
                        {
                            break;
                        }
                        Console.Write(Temp);
                        old = New;
                        New = Temp;
                    }
                    k++;
                    j++;
                }
                while (j <= i);
                if (Temp > n)
                {
                    break;
                }
                Console.WriteLine();
                i++;
            }
            while (i <= n);
            Console.Write("\n");
            i = 1;
            k = 1;
            old = 0;
            New = 0;
            Temp = 0;
            for(i=1;i<=n1;)
            {
                for(int j=1;j<=i;)
                {
                    if (k <= 3)
                    {
                        Console.Write(k);
                        New = k;
                        old = k - 1;
                    }
                    else
                    {
                        Temp = old * New;
                        if(Temp>n1)
                        {
                            break;
                        }
                        Console.Write(Temp);
                        old = New;
                        New = Temp;
                    }
                    k++;
                    j++;
                }
                if(Temp>n1)
                {
                    break;
                }
                Console.WriteLine();
                i++;
            }

        }

    }
}
