﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace serise
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Any Number:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1, k = 1, old=0,New=0,Temp = 0;
            do 
            {
                int j = 1;
                do
                {
                    if (k <= 3)
                    {
                        Console.Write(k);
                        New= k;
                        old = k - 1;
                    }
                    else
                    {
                        Temp = old * New;
                        if (Temp > n)
                        {
                            break;
                        }
                        Console.Write(Temp);
                        old = New;
                        New= Temp;
                    }
                    k++;
                    j++;
                }
                while (j <= i);
                if(Temp>n)
                {
                    break ;
                }
                Console.WriteLine();
                i++;
            }
            while (i <= n) ;
            Console.Read();
        }
    }
}
