﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace switch_case
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter 1 for White BG");
            Console.Write("Enter 2 for Green BG");
            Console.Write("Enter 3 for Red BG");

            int num = Convert.ToInt32(Console.ReadLine());
            switch(num)
            {
                case 1:
                Console.BackgroundColor = ConsoleColor.White;
                Console.Clear();
                break;

                case 2:
                Console.BackgroundColor = ConsoleColor.Green;
                Console.Clear();
                break;

                case 3:
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.Clear();
                    break;
                default:
                    Console.Write("Enter Number Between 1 to 3");
                    break;




                }
                Console.Read();
        }
    }
}
