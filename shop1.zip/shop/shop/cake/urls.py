from django.contrib import admin
from django.urls import path
from cake  import views

urlpatterns = [
    
    path("", views.index, name='cake'),
    path("about", views.about, name='about'),
   
  
    path("contact", views.contact, name='contact'),
    path("menu", views.menu, name='menu'),
    path("service", views.service, name='service'),
    path("team", views.team, name='team'),
    path("testimonial", views.testimonial, name='testimonial'),
 
]    
