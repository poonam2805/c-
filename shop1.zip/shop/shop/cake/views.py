# from django.shortcuts import render

# Create your views here.
from django.shortcuts import render,HttpResponse




# Create your views here.


def index(request):
    context = {
        "vsriable":"this is sent"
    }
    return render(request, 'index.html', context)
    # return HttpResponse("this is home page")

def about(request):
    return render(request, 'about.html')
    # return HttpResponse("this is about page")









def contact(request):
    return render(request, 'contact.html')
    # return HttpResponse("this is contact page")

def menu(request):
    return render(request, 'menu.html')


def service(request):
    return render(request, 'service.html')

def team(request):
    return render(request, 'team.html')

def testimonial(request):
    return render(request, 'testimonial.html')